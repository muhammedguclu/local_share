/*
 * disc_in.c
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#include "main_includes.h"

DISCRETE_IN_STR DiscIn[DISCRETE_IN_LENGTH];

void INIT_FNCT_DiscIn()
{
	DiscIn[DISCRETE_IN_0].Address = 12;
	DiscIn[DISCRETE_IN_1].Address = 7;
	DiscIn[DISCRETE_IN_2].Address = 24;
	DiscIn[DISCRETE_IN_3].Address = 23;
}

unsigned char DISC_IN_GetSingleData(DISCRETE_IN_STR *disc_in)
{
	return gpioRead(disc_in->Address);
}
