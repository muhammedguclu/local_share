/*
 * analog_mux.c
 *
 *  Created on: Nov 17, 2019
 *      Author: pi
 */

#include "main_includes.h"

void ANALOG_MUX_Disable()
{
	gpioWrite(16, 0);
}

void ANALOG_MUX_Enable()
{
	gpioWrite(16, 1);
}

void ANALOG_MUX_EnablePort(unsigned char bus)
{
	switch(bus)
	{
		case MODBUS_BUS_0:
		{
			ANALOG_MUX_Disable();
			gpioWrite(20, 0);
			gpioWrite(21, 0);
			ANALOG_MUX_Enable();
			break;
		}
		case MODBUS_BUS_1:
		{
			ANALOG_MUX_Disable();
			gpioWrite(20, 1);
			gpioWrite(21, 0);
			ANALOG_MUX_Enable();
			break;
		}
		case MODBUS_BUS_2:
		{
			ANALOG_MUX_Disable();
			gpioWrite(20, 0);
			gpioWrite(21, 1);
			ANALOG_MUX_Enable();
			break;
		}
		case MODBUS_BUS_3:
		{
			ANALOG_MUX_Disable();
			gpioWrite(20, 1);
			gpioWrite(21, 1);
			ANALOG_MUX_Enable();
			break;
		}
		default:
		{
			ANALOG_MUX_Disable();
			break;
		}
	}
}
