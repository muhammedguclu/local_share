/*
 * modbus_master.c
 *
 *  Created on: May 23, 2019
 *      Author: pi
 */

#include "main_includes.h"

MODBUS_MASTER_STR ModbusMaster[MODBUS_BUS_SIZE];

void MODBUS_MASTER_ChkTxMsg(unsigned char bus_num)
{
	if(ModbusMaster[bus_num].ComPort->TxMsgEvent == 1)
	{
		ModbusMaster[bus_num].ComPort->TxMsgCrc = MODBUS_CalcCRC(ModbusMaster[bus_num].ComPort->TxMsgCntr, &ModbusMaster[bus_num].ComPort->TxMsgBuf[0]);
		ModbusMaster[bus_num].ComPort->TxMsgBuf[ModbusMaster[bus_num].ComPort->TxMsgCntr++] = (ModbusMaster[bus_num].ComPort->TxMsgCrc & 0xff);
		ModbusMaster[bus_num].ComPort->TxMsgBuf[ModbusMaster[bus_num].ComPort->TxMsgCntr++] = ((ModbusMaster[bus_num].ComPort->TxMsgCrc & 0xff00)>>8);
		SendMessage(ModbusMaster[bus_num].ComPort, ModbusMaster[bus_num].ComPort->TxMsgCntr, &ModbusMaster[bus_num].ComPort->TxMsgBuf[0]);
		ModbusMaster[bus_num].ComPort->TxMsgCntr = 0;
		ModbusMaster[bus_num].ComPort->TxMsgEvent = 0;
	}
}

void INIT_FNCT_ModbusMaster()
{
	ModbusMaster[MODBUS_BUS_0].ComPort = &SerialPort1;
	ModbusMaster[MODBUS_BUS_1].ComPort = &SerialPort1;
	ModbusMaster[MODBUS_BUS_2].ComPort = &SerialPort1;
	ModbusMaster[MODBUS_BUS_3].ComPort = &SerialPort1;
}


void PROC_FNCT_ModbusMaster(MODBUS_MASTER_STR *modbus_master)
{
	if(modbus_master->ComPort->GetCntr != modbus_master->ComPort->RxCntr)
	{
		switch(modbus_master->State)
		{
			case MODBUS_MASTER_STATE_IDLE:
			{
				modbus_master->RTUCntr = 0;
				modbus_master->State = MODBUS_MASTER_STATE_ADDRESS;
				break;
			}
			case MODBUS_MASTER_STATE_ADDRESS:
			{
				MODBUS_MASTER_WriteMasterRTUBuf(modbus_master);
				if(
						(Rs485GatewaySlave[RaspiGateway.Rs485SlaveReadBuf].SlaveAddrOnBus == modbus_master->RTUBuf[0]) ||
						(modbus_master->RTUBuf[0] == MODBUS_MASTER_BROADCAST_ADDRESS)
				)
				{
					modbus_master->State = MODBUS_MASTER_STATE_FUNCTION;
				}
				else
				{
					modbus_master->State = MODBUS_MASTER_STATE_IDLE;
				}
				break;
			}
			case MODBUS_MASTER_STATE_FUNCTION:
			{
				MODBUS_MASTER_WriteMasterRTUBuf(modbus_master);
				if(modbus_master->RTUBuf[1] == MODBUS_FUNC_WRITE_MULTIPLE_REGISTERS)
				{
					modbus_master->num_to_data_read = 4;
					modbus_master->data_read_cntr = 0;
					modbus_master->State = MODBUS_MASTER_STATE_DATA;
				}
				else
				{
					modbus_master->State = MODBUS_MASTER_STATE_BYTE_COUNT;
				}
				break;
			}
			case MODBUS_MASTER_STATE_BYTE_COUNT:
			{
				MODBUS_MASTER_WriteMasterRTUBuf(modbus_master);
				modbus_master->num_to_data_read = modbus_master->RTUBuf[2];
				modbus_master->data_read_cntr = 0;
				modbus_master->State = MODBUS_MASTER_STATE_DATA;
				break;
			}
			case MODBUS_MASTER_STATE_DATA:
			{
				MODBUS_MASTER_WriteMasterRTUBuf(modbus_master);
				modbus_master->data_read_cntr++;
				if(modbus_master->data_read_cntr == modbus_master->num_to_data_read)
				{
					modbus_master->State = MODBUS_MASTER_STATE_END_1;
				}
				break;
			}
			case MODBUS_MASTER_STATE_END_1:
			{
				MODBUS_MASTER_WriteMasterRTUBuf(modbus_master);
				modbus_master->State = MODBUS_MASTER_STATE_END_2;
				break;
			}
			case MODBUS_MASTER_STATE_END_2:
			{
				MODBUS_MASTER_WriteMasterRTUBuf(modbus_master);
				if(modbus_master->ComPort->GetCntr == modbus_master->ComPort->RxCntr)
				{
					modbus_master->ComPort->RxMsgCrc = MODBUS_CalcCRC(modbus_master->RTUCntr, &modbus_master->RTUBuf[0]);
					if(modbus_master->ComPort->RxMsgCrc == 0)
					{
						MODBUS_MASTER_WriteMasterRTUToMsgBuf(modbus_master);
					}
					modbus_master->State = MODBUS_MASTER_STATE_IDLE;
				}
				break;
			}
			default:
			{
				modbus_master->State = MODBUS_MASTER_STATE_IDLE;
				break;
			}
		}

	}
}

void MODBUS_MASTER_WriteMasterRTUBuf(MODBUS_MASTER_STR *modbus_master)
{
	modbus_master->RTUBuf[modbus_master->RTUCntr++] = modbus_master->ComPort->RxDataBuf[modbus_master->ComPort->GetCntr++];
}

void MODBUS_MASTER_WriteMasterRTUToMsgBuf(MODBUS_MASTER_STR *modbus_master)
{
	unsigned int i;
	modbus_master->RxMsgCntr = 0;
	for(i=0;i<modbus_master->RTUCntr;i++)
	{
		modbus_master->RxMsgBuf[modbus_master->RxMsgCntr++] = modbus_master->RTUBuf[i];
	}
	modbus_master->RxMsgEvent = 1;
}


