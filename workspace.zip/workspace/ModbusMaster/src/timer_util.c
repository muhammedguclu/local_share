/*
 * timer_util.c
 *
 *  Created on: May 24, 2019
 *      Author: pi
 */

#include "main_includes.h"

TMR_STR TmrTbl[TMR_TBL_SIZE];

void TmrCfgCriticFnct(unsigned char n, void (* fnct)(void *), void *arg)
{
	TMR_STR *ptmr;
    if(n < TMR_TBL_SIZE)
    {
    	ptmr = &TmrTbl[n];
    	ptmr->CriticFnct = fnct;    //Store pointer to user function into timer.
    	ptmr->CriticFnctArg = arg;  //Store user's function function arguments pointer
    }
}

unsigned int TmrCheckTick(unsigned char n)
{
    unsigned int val = 0;
    if(n < TMR_TBL_SIZE)
    {
        val = TmrTbl[n].TmrCntr;
    }
    return val;
}

void TmrSetTmrInitTick(unsigned char n, unsigned short tmr_tick)
{
    if( n < TMR_TBL_SIZE)
    {
        TmrTbl[n].TmrInit = tmr_tick;
    }
}

void TmrSetTmrTick(unsigned char n, unsigned short tmr_tick)
{
    if( n < TMR_TBL_SIZE)
    {
        TmrTbl[n].TmrCntr = tmr_tick;
    }
}

void TmrStart(unsigned char n)
{
    if(n < TMR_TBL_SIZE)
    {
		TmrTbl[n].CriticFnctEn = TMR_ENABLED;
    }
}

void TmrStop(unsigned char n)
{
    if(n < TMR_TBL_SIZE)
    {
        TmrTbl[n].CriticFnctEn = TMR_DISABLED;
    }
}

void TmrSetTmrType(unsigned char n, unsigned char tmr_type)
{
    if(n < TMR_TBL_SIZE)
    {
        TmrTbl[n].TmrType = tmr_type;
    }
}

void TmrResetTick(unsigned char n)
{
	if(n < TMR_TBL_SIZE)
	{
		TmrTbl[n].TmrCntr = TmrTbl[n].TmrInit;
	}
}

void INT_MNGR_SysTmr()
{
    unsigned char i;
    for(i = 0; i < TMR_TBL_SIZE; i++)
    {
        if(TmrTbl[i].CriticFnctEn == TMR_ENABLED)
        {
            if(TmrTbl[i].TmrCntr > TMR_TIMEOUT_EXPIRED)
            {
                TmrTbl[i].TmrCntr--;
                if(TmrTbl[i].TmrCntr == TMR_TIMEOUT_EXPIRED)
                {
            		if(TmrTbl[i].TmrType == TMR_TYPE_CONTINUOUS)
            		{
            			TmrResetTick(i);
            		}
            		else
            		{
            			TmrStop(i);
            		}
					if(TmrTbl[i].CriticFnct != (void (*)(void *))0)
					{
						(TmrTbl[i].CriticFnct)(TmrTbl[i].CriticFnctArg);
					}
                }
            }
        }
    }
}

void INIT_FNCT_SysTmr()
{
	signal(SIGALRM,INT_MNGR_SysTmr);
	ualarm(10000,10000);

	/*struct sigaction sys_timer_signal;
	struct itimerval sys_timer;

	memset (&sys_timer_signal, 0, sizeof (sys_timer_signal));
	sys_timer_signal.sa_handler = &INT_MNGR_SysTmr;
	sigaction (SIGVTALRM, &sys_timer_signal, NULL);

	sys_timer.it_value.tv_sec = 0;
	sys_timer.it_value.tv_usec = 2800;
	sys_timer.it_interval.tv_sec = 0;
	sys_timer.it_interval.tv_usec = 2800;
	setitimer (ITIMER_VIRTUAL, &sys_timer, NULL);
	*/

}

