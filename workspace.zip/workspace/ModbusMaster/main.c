/*
 * main.c
 *
 *  Created on: Mar 14, 2020
 *      Author: root
 */

#include "main_includes.h"

int main(int argc, char*argv[])
{
	INIT_FNCT_GPIO();
	INIT_FNCT_SysTmr();
	INIT_FNCT_InitialiseInputRegisters();
	INIT_FNCT_DiscIn();
	INIT_FNCT_Coil();
	INIT_FNCT_RealTimeClock();
	INIT_FNCT_SerialPort();
	INIT_FNCT_ModbusMaster();
	INIT_FNCT_RaspiGateway();
	INIT_FNCT_Rs485GatewaySlave();
	INIT_FNCT_UpdateSystemForHoldingRegs();
	INIT_FNCT_SharedMem();

	while(1)
	{
		PROC_FNCT_SerialPort();
		PROC_FNCT_RealTimeClock();
		PROC_FNCT_RaspiGateway();
		PROC_FNCT_ModbusMaster(&ModbusMaster[Rs485GatewaySlave[RaspiGateway.Rs485SlaveReadBuf].ModbusMasterBusAddr]);
		PROC_FNCT_UpdateSystemForHoldingRegs();
	}

    return 0;
}

