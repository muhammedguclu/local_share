/*
 * serial_util.h
 *
 *  Created on: May 23, 2019
 *      Author: pi
 */

#ifndef INC_SERIAL_UTIL_H_
#define INC_SERIAL_UTIL_H_

extern int serial_port;

#define SERIAL_COM_PORT_BUF_LEN	256

typedef struct {
	int Address;
	unsigned char RxCntr;
	unsigned char RxDataBuf[SERIAL_COM_PORT_BUF_LEN];
	short RxMsgCrc;
	unsigned char GetCntr;

	unsigned char TxMsgEvent;
	unsigned int TxMsgCntr;
	char TxMsgBuf[SERIAL_COM_PORT_BUF_LEN];
	short TxMsgCrc;
} COM_PORT;

extern COM_PORT SerialPort1;

void INIT_FNCT_SerialPort();
void PROC_FNCT_SerialPort();

int CheckComPortRx(COM_PORT *com_port);
void ReadMessage(COM_PORT *com_port, unsigned int message_length);
void SendMessage(COM_PORT *com_port, unsigned int message_length, char *ch);

#endif /* INC_SERIAL_UTIL_H_ */
