/*
 * rtc.h
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#ifndef INC_RTC_H_
#define INC_RTC_H_

#define SECS_IN_LEAP_YEAR 		31622400
#define SECS_IN_NON_LEAP_YEAR 	31536000
#define SECS_IN_31DAYS 			2678400
#define SECS_IN_30DAYS 			2592000
#define SECS_IN_29DAYS 			2505600
#define SECS_IN_28DAYS 			2419200
#define SECS_IN_DAY 			86400
#define SECS_IN_HOUR 			3600
#define SECS_IN_MINUTE 			60
#define DEFAULT_BASE_YEAR 		1970
#define DEFAULT_TIMEZONE		3

typedef struct
{
	unsigned char GetEvent;
	unsigned int Year;
	unsigned char Month;
	unsigned char DayOfMonth;
	unsigned char Hour;
	unsigned char Minute;
	unsigned char Second;
}RTC_CLOCK;

extern RTC_CLOCK RealTimeClock;

void INIT_FNCT_RealTimeClock();
void PROC_FNCT_RealTimeClock();



#endif /* INC_RTC_H_ */
