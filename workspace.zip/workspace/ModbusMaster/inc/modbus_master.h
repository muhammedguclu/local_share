/*
 * modbus_master.h
 *
 *  Created on: May 23, 2019
 *      Author: pi
 */

#ifndef INC_MODBUS_MASTER_H_
#define INC_MODBUS_MASTER_H_

#define MODBUS_MASTER_BROADCAST_ADDRESS			0xff

#define MODBUS_BUS_SIZE							4
enum MODBUS_BUS
{
	MODBUS_BUS_0,					//0
	MODBUS_BUS_1,					//1
	MODBUS_BUS_2,					//2
	MODBUS_BUS_3					//3
};

#define MODBUS_MASTER_STATE_IDLE		0
#define MODBUS_MASTER_STATE_ADDRESS		1
#define MODBUS_MASTER_STATE_FUNCTION	2
#define MODBUS_MASTER_STATE_BYTE_COUNT	3
#define MODBUS_MASTER_STATE_DATA		4
#define MODBUS_MASTER_STATE_EXTRA_DATA	5
#define MODBUS_MASTER_STATE_END_1		6
#define MODBUS_MASTER_STATE_END_2		7

typedef struct
{
	//Master COM port address
	COM_PORT *ComPort;

	unsigned char DeviceAddress;
	unsigned char State;
	unsigned char num_to_data_read;
	unsigned char data_read_cntr;
	unsigned int RTUCntr;
	char RTUBuf[SERIAL_COM_PORT_BUF_LEN];
	unsigned int RxMsgEvent;
	unsigned int RxMsgCntr;
	char RxMsgBuf[SERIAL_COM_PORT_BUF_LEN];

} MODBUS_MASTER_STR;

extern MODBUS_MASTER_STR ModbusMaster[MODBUS_BUS_SIZE];

void MODBUS_MASTER_ChkTxMsg(unsigned char bus_num);
void MODBUS_MASTER_ChkRxMsg(MODBUS_MASTER_STR *modbus_master);
void INIT_FNCT_ModbusMaster();
void PROC_FNCT_ModbusMaster();


#endif /* INC_MODBUS_MASTER_H_ */
