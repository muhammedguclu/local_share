/*
 * coil.h
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#ifndef INC_COIL_H_
#define INC_COIL_H_

#define COIL_LENGTH						4

enum {
	COIL_0,				//0
	COIL_1,				//1
	COIL_2,				//2
	COIL_3				//3
} COIL_ENUM;

typedef struct
{
	unsigned int Address;
} COIL_STR;

extern COIL_STR Coil[COIL_LENGTH];

void INIT_FNCT_Coil();
void COIL_SetSingleData(COIL_STR *coil, unsigned char value);
unsigned char COIL_GetSingleData(COIL_STR *coil);

#endif /* INC_COIL_H_ */
