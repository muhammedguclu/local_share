/*
 * timer_util.h
 *
 *  Created on: May 24, 2019
 *      Author: pi
 */

#ifndef INC_TIMER_UTIL_H_
#define INC_TIMER_UTIL_H_

/////////////////////////
#define TMR_ENABLED     1
#define TMR_DISABLED    0

#define TMR_TIMEOUT_EXPIRED     0

#define CALL_TMR_CALLBACK_FUNCTION          1
#define DONT_CALL_TMR_CALLBACK_FUNCTION     0

#define TMR_TYPE_SINGLE			0
#define TMR_TYPE_CONTINUOUS		1

#define TMR_TBL_SIZE                 3
//Do not forget to update TMR_MAX_TMR value when you have defined a new timer.
enum TMR_TBL
{
	RTC_TIMER,					//0
	RASPI_GATEWAY_TIMER,		//1
	ANALOG_MUX_TIMER			//2
//	WS10_TIMER					//3
//	SERIAL_PORT_READ_TIMER		//3
};

#define SYS_TMR_PERIOD_MS				10
#define SYS_TMR_FREQ                    100
#define MSEC_10_TO_TICK(i)              (i)
#define SEC_TO_TICK(i)                  (SYS_TMR_FREQ * (i))

#define RTC_TIMER_TICK       			SEC_TO_TICK(1)
#define RASPI_GATEWAY_TIMER_TICK		MSEC_10_TO_TICK(40)
#define ANALOG_MUX_TIMER_TICK			MSEC_10_TO_TICK(5)
//#define WS10_TIMER_TICK					SEC_TO_TICK(1)
//#define SERIAL_PORT_READ_TIMER_TICK		MSEC_10_TO_TICK(15)

typedef struct
{
	unsigned char TmrType;
    unsigned char CriticFnctEn;
    unsigned int TmrInit;
    unsigned int TmrCntr;
    void (*CriticFnct)(void *);
    void *CriticFnctArg;
} TMR_STR;

extern TMR_STR TmrTbl[TMR_TBL_SIZE];

void TmrCfgCriticFnct(unsigned char n, void (* fnct)(void *), void *arg);
unsigned int TmrCheckTick(unsigned char n);
void TmrSetTmrInitTick(unsigned char n, unsigned short tmr_tick);
void TmrSetTmrTick(unsigned char n, unsigned short tmr_tick);
void TmrResetTick( unsigned char n);
void TmrStart(unsigned char n);
void TmrStop(unsigned char n);
void TmrSetTmrType(unsigned char n, unsigned char tmr_type);

void INT_MNGR_SysTmr();

void INIT_FNCT_SysTmr();


#endif /* INC_TIMER_UTIL_H_ */
