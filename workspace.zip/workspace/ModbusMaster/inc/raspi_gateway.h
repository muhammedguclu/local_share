/*
 * raspi_gateway.h
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#ifndef INC_RASPI_GATEWAY_H_
#define INC_RASPI_GATEWAY_H_

typedef struct
{
	unsigned char Mode;
	unsigned char Rs485SlaveEnableCounter;
	unsigned char Rs485SlaveReadBuf;
	unsigned char Rs485SlaveAskWhat;
	unsigned char Rs485SlaveAskSubSlave;
} RASPI_GATEWAY_STR;

extern RASPI_GATEWAY_STR RaspiGateway;

void RASPI_GATEWAY_ChangeMode(unsigned char mode);
void INIT_FNCT_RaspiGateway();
void PROC_FNCT_RaspiGateway();

#endif /* INC_RASPI_GATEWAY_H_ */
