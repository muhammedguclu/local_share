/*
 * logger.h
 *
 *  Created on: May 24, 2019
 *      Author: pi
 */

#ifndef INC_LOGGER_H_
#define INC_LOGGER_H_

#define MAX_NUMBER_OF_DTKS 			8
#define MAX_NUMBER_OF_STRINGS		24

#define CURRENT_PLANT_CODE		2

typedef struct
{
	unsigned char LogPlantCode;
	unsigned char LogDTKCode;
	unsigned char LogStringCode;
	unsigned char LogYear;
	unsigned char LogMonth;
	unsigned char LogDay;
	unsigned char LogHour;
	unsigned char LogMinute;
	unsigned char LogSecond;
	short LogStatus;
	short LogCurrent; 	//-250 to 2500
	short LogVoltage; 	//-2000 to 12000
	short LogTemp;    	//-50 to 100
	int GenLogPower;	// -500000 to 30000000
} LOGGER_STR;

extern LOGGER_STR Logger[(MAX_NUMBER_OF_DTKS * MAX_NUMBER_OF_STRINGS)];

void LOGGER_PrintTime();

#endif /* INC_LOGGER_H_ */
