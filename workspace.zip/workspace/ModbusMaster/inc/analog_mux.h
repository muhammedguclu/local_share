/*
 * analog_mux.h
 *
 *  Created on: Nov 17, 2019
 *      Author: pi
 */

#ifndef INC_ANALOG_MUX_H_
#define INC_ANALOG_MUX_H_

void ANALOG_MUX_Disable();
void ANALOG_MUX_Enable();
void ANALOG_MUX_EnablePort(unsigned char bus);

#endif /* INC_ANALOG_MUX_H_ */
