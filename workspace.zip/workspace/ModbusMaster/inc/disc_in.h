/*
 * disc_in.h
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#ifndef INC_DISC_IN_H_
#define INC_DISC_IN_H_

#define DISCRETE_IN_LENGTH					4

enum {
	DISCRETE_IN_0,
	DISCRETE_IN_1,
	DISCRETE_IN_2,
	DISCRETE_IN_3
} DISCRETE_IN_ENUM;

typedef struct
{
	unsigned int Address;
} DISCRETE_IN_STR;

extern DISCRETE_IN_STR DiscIn[DISCRETE_IN_LENGTH];

void INIT_FNCT_DiscIn();
unsigned char DISC_IN_GetSingleData(DISCRETE_IN_STR *disc_in);

#endif /* INC_DISC_IN_H_ */
