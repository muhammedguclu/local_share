/*
 * holding_regs.c
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#include "main_includes.h"

HOLDING_REGISTER_STR HoldingReg[HOLDING_REGISTER_LENGTH];


