/*
 * modbus_master.c
 *
 *  Created on: May 23, 2019
 *      Author: pi
 */

#include "main_includes.h"

MODBUS_MASTER_STR ModbusMaster[MODBUS_BUS_SIZE];

void MODBUS_MASTER_ChkTxMsg(MODBUS_MASTER_STR *modbus_master)
{
	if(modbus_master->TxMsgEvent == 1)
	{
		modbus_master->TxMsgCrc = MODBUS_CalcCRC(modbus_master->TxMsgCntr, &modbus_master->TxMsgBuf[0]);
		modbus_master->TxMsgBuf[modbus_master->TxMsgCntr++] = (modbus_master->TxMsgCrc & 0xff);
		modbus_master->TxMsgBuf[modbus_master->TxMsgCntr++] = (modbus_master->TxMsgCrc & 0xff00)>>8;
		SendMessage(modbus_master->ComPort, modbus_master->TxMsgCntr, &modbus_master->TxMsgBuf[0]);
		modbus_master->TxMsgCntr = 0;
		modbus_master->TxMsgEvent = 0;
	}
}

void MODBUS_MASTER_ChkRxMsg(MODBUS_MASTER_STR *modbus_master)
{
	unsigned int serial_port_buf = CheckComPortRx((COM_PORT *)modbus_master->ComPort);
	if(serial_port_buf > 0)
	{
		printf("Response Received\n");
		ReadMessage((COM_PORT *)modbus_master->ComPort, serial_port_buf);
	}
	modbus_master->RxTempMsgCntr = 0;
	for(;modbus_master->RxMsgCntr != modbus_master->ComPort->RxCntr;)
	{
		modbus_master->RxMsgBuf[modbus_master->RxTempMsgCntr++] = modbus_master->ComPort->RxDataBuf[modbus_master->RxMsgCntr++];
		if(modbus_master->RxMsgCntr >= SERIAL_COM_PORT_BUF_LEN)
		{
			modbus_master->RxMsgCntr = 0;
		}
	}
	if(modbus_master->RxTempMsgCntr > 0)
	{
		modbus_master->RxMsgCrc = MODBUS_CalcCRC((modbus_master->RxTempMsgCntr-2), &modbus_master->RxMsgBuf[0]);
		if(
				(modbus_master->RxMsgBuf[(modbus_master->RxTempMsgCntr-2)] == (modbus_master->RxMsgCrc & 0xff)) &&
				(modbus_master->RxMsgBuf[(modbus_master->RxTempMsgCntr-1)] == ((modbus_master->RxMsgCrc & 0xff00)>>8))
				)
		{
			modbus_master->RxMsgEvent = 1;
		}
	}
}

void MODBUS_MASTER_FlushBuffer(MODBUS_MASTER_STR *modbus_master)
{
	modbus_master->RxMsgCntr = 0;
	modbus_master->ComPort->RxCntr = 0;
}

void INIT_FNCT_ModbusMaster()
{
	ModbusMaster[MODBUS_BUS_0].ComPort = &SerialPort1;
	ModbusMaster[MODBUS_BUS_1].ComPort = &SerialPort1;
	ModbusMaster[MODBUS_BUS_2].ComPort = &SerialPort1;
	ModbusMaster[MODBUS_BUS_3].ComPort = &SerialPort1;
}


void PROC_FNCT_ModbusMaster()
{

}
