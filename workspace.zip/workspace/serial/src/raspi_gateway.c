/*
 * raspi_gateway.c
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#include "main_includes.h"

RASPI_GATEWAY_STR RaspiGateway;

void RS485_GATEWAY_ChangeMode(unsigned char mode)
{
	HoldingReg[HOLD_REG_OPERATION_MODE].Data = mode;
	RaspiGateway.Mode = HoldingReg[HOLD_REG_OPERATION_MODE].Data;
}

