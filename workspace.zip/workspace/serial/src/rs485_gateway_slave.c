/*
 * rs485_gateway_slave.c
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#include "main_includes.h"

RS485_GATEWAY_SLAVE_STR Rs485GatewaySlave[RS485_GATEWAY_SLAVE_LENGTH];

unsigned char Rs485SlaveEnableCounter;
unsigned char Rs485SlaveReadBuf;
unsigned char Rs485SlaveAskWhat;

void INIT_FNCT_SolarTrackerSlave()
{
	Rs485SlaveEnableCounter = 0;
	Rs485SlaveReadBuf = 0;
	Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_ASK_HOLDING_REGISTERS;

}

