/*
 * raspi_gateway.h
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#ifndef INC_RASPI_GATEWAY_H_
#define INC_RASPI_GATEWAY_H_

typedef struct
{
	unsigned char Mode;
} RASPI_GATEWAY_STR;

extern RASPI_GATEWAY_STR RaspiGateway;

#endif /* INC_RASPI_GATEWAY_H_ */
