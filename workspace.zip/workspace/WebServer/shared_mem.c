/*
 * shared_mem.c
 *
 *  Created on: Mar 21, 2020
 *      Author: root
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <semaphore.h>
#include <string.h>
#include "shared_mem.h"

short* SharedMemPtr;

INPUT_REGISTER_STR InputReg[INPUT_REGISTER_LENGTH];
HOLDING_REGISTER_STR HoldingReg[HOLDING_REGISTER_LENGTH];

void SHARED_MEM_ReportAndExit(const char *msg)
{
	perror(msg);
	exit(-1);
}

void INIT_FNCT_SharedMem()
{
	int fd = shm_open(SHARED_MEM_BACKING_FILE, (O_RDWR), SHARED_MEM_ACCESS_PERMS);

	if(fd < 0)
	{
		SHARED_MEM_ReportAndExit("Can't open shared mem segment...");
	}

	SharedMemPtr = mmap(
					NULL,
					SHARED_MEM_BYTE_SIZE,
					(PROT_READ | PROT_WRITE),
					MAP_SHARED,
					fd,
					0
					);

	if((short) -1 == SharedMemPtr)
	{
		SHARED_MEM_ReportAndExit("Can't get segment...");
	}

	fprintf(stderr,"shared mem address: %p [0..%d]\n", SharedMemPtr, (SHARED_MEM_BYTE_SIZE-1));
	fprintf(stderr, "backing file:       /dev/shm%s\n", SHARED_MEM_BACKING_FILE);

}

void SHARED_MEM_ReadAllRegs()
{
	memcpy(InputReg, SharedMemPtr, INPUT_REGISTER_LENGTH);
	memcpy(HoldingReg, (SharedMemPtr+INPUT_REGISTER_LENGTH),HOLDING_REGISTER_LENGTH);
}
