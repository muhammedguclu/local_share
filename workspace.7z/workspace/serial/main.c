/*
 * main.c
 *
 *  Created on: May 23, 2019
 *      Author: pi
 */

#include "main_includes.h"

short GetRowValueFromFile(char *file_name, int row)
{
	FILE *fp = fopen(file_name, "r");
	if (!fp)
	{
		printf("Can't open file\n");
		return -1;
	}
	char buf[1024];

	int row_count = 0;
	int field_count = 0;
	while (fgets(buf, 1024, fp))
	{
		if(row_count == row)
		{
			char *field = strtok(buf, ",");
			while (field)
			{
				//printf("%s\n", field);
				field = strtok(NULL, ",");
				field_count++;
				if(field_count == 1)
				{
					return atoi(field);
					//printf("%s\n", field);
				}
			}
		}
		row_count++;
	}
	return -1;
}

int main(int argc, char*argv[])
{
	INIT_FNCT_GPIO();

	INIT_FNCT_InitialiseInputRegisters();
	INIT_FNCT_DiscIn();
	INIT_FNCT_Coil();
	INIT_FNCT_RealTimeClock();

	ANALOG_MUX_EnablePort(MODBUS_BUS_1);

	int fd = shm_open(SHARED_MEM_BACKING_FILE, (O_RDWR | O_CREAT), SHARED_MEM_ACCESS_PERMS);

	if(fd < 0)
	{
		SHARED_MEM_ReportAndExit("Can't open shared mem segment...");
	}

	ftruncate(fd, SHARED_MEM_BYTE_SIZE);

	caddr_t memptr = mmap(
			NULL,
			SHARED_MEM_BYTE_SIZE,
			(PROT_READ | PROT_WRITE),
			MAP_SHARED,
			fd,
			0
			);

	if((caddr_t) -1 == memptr)
	{
		SHARED_MEM_ReportAndExit("Can't get segment...");
	}

	fprintf(stderr,"shared mem address: %p [0..%d]\n", memptr, (SHARED_MEM_BYTE_SIZE-1));
	fprintf(stderr, "backing file:       /dev/shm%s\n", SHARED_MEM_BACKING_FILE);

	sem_t* semptr = sem_open(
			SHARED_MEM_SEMAPHORE_NAME,
			O_CREAT,
			SHARED_MEM_ACCESS_PERMS,
			0
			);

	if(semptr == (void*) -1)
	{
		SHARED_MEM_ReportAndExit("sem_post");
	}

	strcpy(memptr, SHARED_MEM_CONTENTS);

	if(sem_post(semptr) < 0)
	{
		SHARED_MEM_ReportAndExit("sem_post");
	}

	sleep(12);

	munmap(memptr, SHARED_MEM_BYTE_SIZE);
	close(fd);
	sem_close(semptr);
	shm_unlink(SHARED_MEM_BACKING_FILE);



	/*
	int s = -1;
	modbus_t *ctx;
	uint8_t *query;
	int header_length;
	int rc;

	ctx = modbus_new_tcp("0.0.0.0", 503);
	query = malloc(MODBUS_TCP_MAX_ADU_LENGTH);
	header_length = modbus_get_header_length(ctx);

	modbus_set_debug(ctx, TRUE);
	s = modbus_tcp_listen(ctx, 1);
	modbus_tcp_accept(ctx, &s);

	while(1)
	{
		PROC_FNCT_RealTimeClock();
		rc = modbus_receive(ctx, query);
		if (rc == -1)
		{
			break;
		}
	}
	*/

    return 0;
}

