/*
 * string_monitor.c
 *
 *  Created on: May 23, 2019
 *      Author: pi
 */

#include "main_includes.h"

STRING_MONITOR_STR StringMonitor;

void STRING_MON_GetSCKChannelData(MODBUS_MASTER_STR *modbus_master, unsigned char slave_address)
{
	modbus_master->TxMsgBuf[modbus_master->TxMsgCntr++] = slave_address;
	modbus_master->TxMsgBuf[modbus_master->TxMsgCntr++] = MODBUS_FUNC_READ_HOLDING_REGISTERS;
	modbus_master->TxMsgBuf[modbus_master->TxMsgCntr++] = (SCK_CHANNEL_1_DATA_START_ADDR & 0xff00)>>8;
	modbus_master->TxMsgBuf[modbus_master->TxMsgCntr++] = (SCK_CHANNEL_1_DATA_START_ADDR & 0x00ff);
	modbus_master->TxMsgBuf[modbus_master->TxMsgCntr++] = (SCK_CHANNEL_8_DATA_START_ADDR & 0xff00)>>8;
	modbus_master->TxMsgBuf[modbus_master->TxMsgCntr++] = (SCK_CHANNEL_8_DATA_START_ADDR & 0x00ff);
	modbus_master->TxMsgEvent = 1;
}

void STRING_MON_HandleSCKChannelMessage(MODBUS_MASTER_STR *modbus_master)
{
	if(modbus_master->RxMsgEvent == 1)
	{
		time_t T = time(NULL);
		struct tm tm = *localtime(&T);
		//printf("System Date is: %02d/%02d/%04d\n",tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900);
		//printf("System Time is: %02d:%02d:%02d\n",tm.tm_hour, tm.tm_min, tm.tm_sec);
		unsigned char i,j;
		switch(modbus_master->RxMsgBuf[0])
		{
			case STRING_MONITOR_1_MODBUS_ADDR:
			{
				StringMonitor.CurrentDTK = 0;
				StringMonitor.CurrentDTKGroup = 0;
				break;
			}
			case STRING_MONITOR_3_MODBUS_ADDR:
			{
				StringMonitor.CurrentDTK = 2;
				StringMonitor.CurrentDTKGroup = 1;
				break;
			}
			case STRING_MONITOR_5_MODBUS_ADDR:
			{
				StringMonitor.CurrentDTK = 4;
				StringMonitor.CurrentDTKGroup = 2;
				break;
			}
			case STRING_MONITOR_7_MODBUS_ADDR:
			{
				StringMonitor.CurrentDTK = 6;
				StringMonitor.CurrentDTKGroup = 3;
				break;
			}
			default:
			{
				break;
			}
		}
		for(i=0;i<7;i++)
		{
			if(i<3)
			{
				for(j=0;j<8;j++)
				{
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogPlantCode = StringMonitor.CurrentPlant;
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogDTKCode = StringMonitor.CurrentDTK;
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogStringCode = StringMonitor.CurrentString;
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogYear = tm.tm_year;
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogMonth = tm.tm_mon;
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogDay = tm.tm_mday;
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogHour = tm.tm_hour;
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogMinute = tm.tm_min;
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogSecond = tm.tm_sec;
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogStatus = (((modbus_master->RxMsgBuf[3+i*22])<<8) + modbus_master->RxMsgBuf[4+i*22]);
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogCurrent = (((modbus_master->RxMsgBuf[5+i*22+j*2])<<8) + modbus_master->RxMsgBuf[6+i*22+j*2]);
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogVoltage = (((modbus_master->RxMsgBuf[23+i*22])<<8) + modbus_master->RxMsgBuf[24+i*22]);
					Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogTemp = (((modbus_master->RxMsgBuf[21+i*22])<<8) + modbus_master->RxMsgBuf[22+i*22]);
					printf("DTK:%d String:%d Current:%d Voltage:%d Temp:%d\n",(Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogDTKCode+1),(StringMonitor.CurrentString+1),Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogCurrent,Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogVoltage,Logger[StringMonitor.CurrentDTKGroup*48+i*8+j].LogTemp);
					StringMonitor.CurrentString++;
					if(StringMonitor.CurrentString >= 24)
					{
						StringMonitor.CurrentString = 0;
					}
				}
			}
			else
			{
				for(j=0;j<8;j++)
				{
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogPlantCode = StringMonitor.CurrentPlant;
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogDTKCode = StringMonitor.CurrentDTK;
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogStringCode = StringMonitor.CurrentString;
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogYear = tm.tm_year;
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogMonth = tm.tm_mon;
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogDay = tm.tm_mday;
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogHour = tm.tm_hour;
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogMinute = tm.tm_min;
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogSecond = tm.tm_sec;
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogStatus = (((modbus_master->RxMsgBuf[3+i*22])<<8) + modbus_master->RxMsgBuf[4+i*22]);
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogCurrent = (((modbus_master->RxMsgBuf[5+i*22+j*2])<<8) + modbus_master->RxMsgBuf[6+i*22+j*2]);
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogVoltage = (((modbus_master->RxMsgBuf[23+i*22])<<8) + modbus_master->RxMsgBuf[24+i*22]);
					Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogTemp = (((modbus_master->RxMsgBuf[21+i*22])<<8) + modbus_master->RxMsgBuf[22+i*22]);
					printf("DTK:%d String:%d Current:%d Voltage:%d Temp:%d\n",(Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogDTKCode+1),(StringMonitor.CurrentString+1),Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogCurrent,Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogVoltage,Logger[StringMonitor.CurrentDTKGroup*48+(i-1)*8+j].LogTemp);
					StringMonitor.CurrentString++;
					if(StringMonitor.CurrentString >= 24)
					{
						StringMonitor.CurrentString = 0;
					}
				}
			}
			if(i==2)
			{
				i++;
				StringMonitor.CurrentDTK++;
				if(StringMonitor.CurrentDTK >= 8)
				{
					StringMonitor.CurrentDTK = 0;
				}
			}
		}
		modbus_master->RxMsgEvent = 0;
	}
}
