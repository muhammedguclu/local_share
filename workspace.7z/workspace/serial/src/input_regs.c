/*
 * input_regs.c
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#include "main_includes.h"

INPUT_REGISTER_STR InputReg[INPUT_REGISTER_LENGTH];

void INIT_FNCT_InitialiseInputRegisters()
{
	InputReg[RASPI_INPUT_REGS_SW_VER].Data = SW_VERSION;
	InputReg[RASPI_INPUT_REGS_FW_VER].Data = FW_VERSION;
	InputReg[RASPI_INPUT_REGS_HW_VER].Data = HW_VERSION;

	HoldingReg[HOLD_REG_MODBUS_DEV_ADDR].Data = GetRowValueFromFile("/home/pi/workspace/serial/board_config/8_main_board_config.csv", CONFIG_FILE_MODBUS_DEV_ADDR);
	HoldingReg[HOLD_REG_SPECIFIC_CODE].Data = GetRowValueFromFile("/home/pi/workspace/serial/board_config/8_main_board_config.csv", CONFIG_FILE_SPECIFIC_CODE_ADDR);
	HoldingReg[HOLD_REG_BOARD_SERIAL_1].Data = GetRowValueFromFile("/home/pi/workspace/serial/board_config/8_main_board_config.csv", CONFIG_FILE_BOARD_SERIAL_1_ADDR);
	HoldingReg[HOLD_REG_BOARD_SERIAL_2].Data = GetRowValueFromFile("/home/pi/workspace/serial/board_config/8_main_board_config.csv", CONFIG_FILE_BOARD_SERIAL_2_ADDR);
	HoldingReg[HOLD_REG_PROJECT_NUM].Data = GetRowValueFromFile("/home/pi/workspace/serial/board_config/8_main_board_config.csv", CONFIG_FILE_PROJECT_NUM_ADDR);
	HoldingReg[HOLD_REG_MAX_NUMBER_OF_SLAVES].Data = GetRowValueFromFile("/home/pi/workspace/serial/board_config/8_main_board_config.csv", CONFIG_FILE_MAX_NUMBER_OF_SLAVES_ADDR);
	HoldingReg[HOLD_REG_PORT_READ_TIMER].Data = GetRowValueFromFile("/home/pi/workspace/serial/board_config/8_main_board_config.csv", CONFIG_FILE_PORT_READ_TIMER_ADDR);
	HoldingReg[HOLD_REG_ANALOG_MUX_EN_TMR].Data = GetRowValueFromFile("/home/pi/workspace/serial/board_config/8_main_board_config.csv", CONFIG_FILE_ANALOG_MUX_ENABLE_TIMER_ADDR);

	if(HoldingReg[HOLD_REG_SPECIFIC_CODE].Data == SPECIFIC_CODE_CONFIG_FILE_SUCCESS)
	{
		RS485_GATEWAY_ChangeMode(HOLD_REG_OPERATION_MODE_OPERATION);
	}
	else
	{
		RS485_GATEWAY_ChangeMode(HOLD_REG_OPERATION_MODE_FIRST_TEST);
	}

}


