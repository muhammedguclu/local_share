/*
 * rtc.c
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#include "main_includes.h"

RTC_CLOCK RealTimeClock;

unsigned char leap_year(uint16_t year)
{
	if (year & 3) {
		return 0;
	} else {
		return 1;
	}
}

uint32_t get_secs_in_month(uint32_t year, uint8_t month)
{
	uint32_t sec_in_month = 0;

	if (leap_year(year)) {
		switch (month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			sec_in_month = SECS_IN_31DAYS;
			break;
		case 2:
			sec_in_month = SECS_IN_29DAYS;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			sec_in_month = SECS_IN_30DAYS;
			break;
		default:
			break;
		}
	} else {
		switch (month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			sec_in_month = SECS_IN_31DAYS;
			break;
		case 2:
			sec_in_month = SECS_IN_28DAYS;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			sec_in_month = SECS_IN_30DAYS;
			break;
		default:
			break;
		}
	}

	return sec_in_month;
}

void convert_timestamp_to_datetime(uint32_t ts)
{
	uint32_t tmp, sec_in_year, sec_in_month;
	uint32_t tmp_year    = DEFAULT_BASE_YEAR;
	uint8_t  tmp_month   = 1;
	uint8_t  tmp_day     = 1;
	uint8_t  tmp_hour    = 0;
	uint8_t  tmp_minutes = 0;

	tmp = ts;

	/* Find year */
	while (1) {
		sec_in_year = leap_year(tmp_year) ? SECS_IN_LEAP_YEAR : SECS_IN_NON_LEAP_YEAR;

		if (tmp >= sec_in_year) {
			tmp -= sec_in_year;
			tmp_year++;
		} else {
			break;
		}
	}
	/* Find month of year */
	while (1) {
		sec_in_month = get_secs_in_month(tmp_year, tmp_month);

		if (tmp >= sec_in_month) {
			tmp -= sec_in_month;
			tmp_month++;
		} else {
			break;
		}
	}
	/* Find day of month */
	while (1) {
		if (tmp >= SECS_IN_DAY) {
			tmp -= SECS_IN_DAY;
			tmp_day++;
		} else {
			break;
		}
	}
	/* Find hour of day */
	while (1) {
		if (tmp >= SECS_IN_HOUR) {
			tmp -= SECS_IN_HOUR;
			tmp_hour++;
		} else {
			break;
		}
	}
	/* Find minute in hour */
	while (1) {
		if (tmp >= SECS_IN_MINUTE) {
			tmp -= SECS_IN_MINUTE;
			tmp_minutes++;
		} else {
			break;
		}
	}

	RealTimeClock.Year = tmp_year;
	RealTimeClock.Month = tmp_month;
	RealTimeClock.DayOfMonth = tmp_day;

	if((tmp_hour + DEFAULT_TIMEZONE) < 24)
	{
		RealTimeClock.Hour = tmp_hour + DEFAULT_TIMEZONE;
	}
	else
	{
		RealTimeClock.Hour = tmp_hour + DEFAULT_TIMEZONE - 24;
	}

	RealTimeClock.Minute = tmp_minutes;
	RealTimeClock.Second = tmp;
}

void RTC_TimerTask()
{
	RealTimeClock.GetEvent = 1;
}

void RTC_ReadTime()
{
	struct timeval ts;
	gettimeofday(&ts, NULL);
	convert_timestamp_to_datetime(ts.tv_sec);
	HoldingReg[HOLD_REG_RTC_YEAR].Data = RealTimeClock.Year-2000;
	HoldingReg[HOLD_REG_RTC_MONTH].Data = RealTimeClock.Month;
	HoldingReg[HOLD_REG_RTC_DAY_OF_MONTH].Data = RealTimeClock.DayOfMonth;
	HoldingReg[HOLD_REG_RTC_HOUR].Data = RealTimeClock.Hour;
	HoldingReg[HOLD_REG_RTC_MINUTE].Data = RealTimeClock.Minute;
	HoldingReg[HOLD_REG_RTC_SECOND].Data = RealTimeClock.Second;
}

void INIT_FNCT_RealTimeClock()
{
	struct sigaction rtc_signal;
	struct itimerval rtc_timer;

	memset (&rtc_signal, 0, sizeof (rtc_signal));
	rtc_signal.sa_handler = &RTC_TimerTask;
	sigaction (SIGVTALRM, &rtc_signal, NULL);

	rtc_timer.it_value.tv_sec = 1;
	rtc_timer.it_value.tv_usec = 0;
	rtc_timer.it_interval.tv_sec = 1;
	rtc_timer.it_interval.tv_usec = 0;
	setitimer (ITIMER_VIRTUAL, &rtc_timer, NULL);

	RTC_ReadTime();
}

void PROC_FNCT_RealTimeClock()
{
	if(RealTimeClock.GetEvent == 1)
	{
		RTC_ReadTime();
		RealTimeClock.GetEvent = 0;
	}
}
