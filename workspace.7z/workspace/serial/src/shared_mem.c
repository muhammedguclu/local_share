/*
 * shared_mem.c
 *
 *  Created on: Mar 14, 2020
 *      Author: root
 */

#include "main_includes.h"

void SHARED_MEM_ReportAndExit(unsigned char *msg)
{
	perror(msg);
	exit(-1);
}

