/*
 * main_includes.h
 *
 *  Created on: May 23, 2019
 *      Author: pi
 */

#ifndef INC_MAIN_INCLUDES_H_

#define INC_MAIN_INCLUDES_H_

#define SW_VERSION	1
#define FW_VERSION	1
#define HW_VERSION	1

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <signal.h>
#include <sys/time.h>
#include <semaphore.h>


#include "wiringPi.h"
#include "wiringSerial.h"


#include <modbus.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "config.h"
#include "gpio.h"
#include "serial_util.h"
#include "modbus_master.h"
#include "modbus_common.h"
#include "string_monitor.h"
#include "logger.h"
#include "analog_mux.h"
#include "input_regs.h"
#include "rtc.h"
#include "holding_regs.h"
#include "rs485_gateway_slave.h"
#include "raspi_gateway.h"
#include "disc_in.h"
#include "coil.h"
#include "shared_mem.h"


#endif /* INC_MAIN_INCLUDES_H_ */
