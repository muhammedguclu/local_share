/*
 * modbus_master.h
 *
 *  Created on: May 23, 2019
 *      Author: pi
 */

#ifndef INC_MODBUS_MASTER_H_
#define INC_MODBUS_MASTER_H_

#define MODBUS_BUS_SIZE							4
enum MODBUS_BUS
{
	MODBUS_BUS_0,					//0
	MODBUS_BUS_1,					//1
	MODBUS_BUS_2,					//2
	MODBUS_BUS_3					//3
};

typedef struct
{
	//Master COM port address
	COM_PORT *ComPort;

	//Master TX buffers
	unsigned char TxMsgEvent;
	unsigned int TxMsgCntr;
	char TxMsgBuf[SERIAL_COM_PORT_BUF_LEN];
	short TxMsgCrc;

	//Master RX buffers
	unsigned char RxMsgEvent;
	unsigned int RxMsgCntr;
	char RxMsgBuf[SERIAL_COM_PORT_BUF_LEN];
	short RxMsgCrc;

	unsigned int RxTempMsgCntr;

} MODBUS_MASTER_STR;

extern MODBUS_MASTER_STR ModbusMaster[MODBUS_BUS_SIZE];

void MODBUS_MASTER_ChkTxMsg(MODBUS_MASTER_STR *modbus_master);
void MODBUS_MASTER_ChkRxMsg(MODBUS_MASTER_STR *modbus_master);
void INIT_FNCT_ModbusMaster();
void PROC_FNCT_ModbusMaster();


#endif /* INC_MODBUS_MASTER_H_ */
