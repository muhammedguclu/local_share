/*
 * shared_mem.h
 *
 *  Created on: Mar 14, 2020
 *      Author: root
 */

#ifndef INC_SHARED_MEM_H_
#define INC_SHARED_MEM_H_

#define SHARED_MEM_BYTE_SIZE	512
#define SHARED_MEM_BACKING_FILE "/shMemEx"
#define SHARED_MEM_ACCESS_PERMS	0644
#define SHARED_MEM_SEMAPHORE_NAME	"shared_mem_semaphore"
#define SHARED_MEM_CONTENTS "HELLO WORLD!! \n"

#endif /* INC_SHARED_MEM_H_ */
