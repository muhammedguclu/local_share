/*
 * ServerReply.h
 *
 *  Created on: Mar 23, 2020
 *      Author: root
 */

#ifndef SERVERREPLY_H_
#define SERVERREPLY_H_

void get_all_hold_reg_vals(int fd, unsigned char reg_num, char *reg_name);
void get_all_inp_reg_vals(int fd, unsigned char reg_num, char *reg_name);
void get_str_val(int fd, unsigned char box_num, unsigned char str_num);
void get_d21(int fd);

#endif /* SERVERREPLY_H_ */
