#ifndef _MIME_H_
#define _MIME_H_

extern char *mime_type_get(char *filename);

#endif