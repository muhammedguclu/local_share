/*
 * ws10_util.c
 *
 *  Created on: Apr 11, 2020
 *      Author: root
 */

#include "main_includes.h"

WS10_LOG WS10Current;
WS10_LOG WS10MinLogBuf[WS10_LOG_BUF_LENGTH];
WS10_LOG WS10MinLog;


WS10_SENS WS10Sens;

void WS10_TimerTask()
{
	WS10Current.AskEvent = 1;
}

void INIT_FNCT_WS10()
{
	WS10Sens.LogCntr = 0;
	ANALOG_MUX_EnablePort(MODBUS_BUS_1);
	TmrSetTmrType(WS10_TIMER, TMR_TYPE_CONTINUOUS);
	TmrCfgCriticFnct(WS10_TIMER, WS10_TimerTask, (void *) 0);
	TmrSetTmrInitTick(WS10_TIMER, WS10_TIMER_TICK);
	TmrResetTick(WS10_TIMER);
	TmrStart(WS10_TIMER);
}

void PROC_FNCT_WS10()
{
	if(WS10Current.AskEvent == 1)
	{
		WS10_AskData();
		MODBUS_MASTER_ChkTxMsg(MODBUS_BUS_1);
		WS10Current.AskEvent = 0;
	}
	WS10_HandleMsg(&ModbusMaster[MODBUS_BUS_1]);
}

void WS10_HandleMsg(MODBUS_MASTER_STR *modbus)
{
	if(modbus->RxMsgEvent == 1)
	{
		switch(modbus->RxMsgBuf[MODBUS_INDEX_FUNCTION])
		{
			case MODBUS_FUNC_READ_INPUT_REGISTERS:
			{
				WS10Current.AirTemperature = (modbus->RxMsgBuf[(WS10_INP_REG_MET_AIR_TEMPERATURE-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_AIR_TEMPERATURE-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.DewpointTemperature = (modbus->RxMsgBuf[(WS10_INP_REG_MET_DEWPOINT_TEMPERATURE-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_DEWPOINT_TEMPERATURE-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.RelativeHumidity = (modbus->RxMsgBuf[(WS10_INP_REG_MET_RELATIVE_HUMIDITY-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_RELATIVE_HUMIDITY-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.AbsoluteAirPressure = (modbus->RxMsgBuf[(WS10_INP_REG_MET_ABSOLUTE_AIR_PRESSURE-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_ABSOLUTE_AIR_PRESSURE-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.WindSpeed = (modbus->RxMsgBuf[(WS10_INP_REG_MET_WIND_SPEED_KM_HR-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_WIND_SPEED_KM_HR-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.WindDirectionCompass = (modbus->RxMsgBuf[(WS10_INP_REG_MET_WIND_DIRECTION_COMPASS_CORRECTION-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_WIND_DIRECTION_COMPASS_CORRECTION-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.PrecititationType = modbus->RxMsgBuf[(WS10_INP_REG_MET_PRECIPITATION_TYPE-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.PrecititationIntensity = (modbus->RxMsgBuf[(WS10_INP_REG_MET_PRECIPITATION_INTENSITY_MM_MIN-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_PRECIPITATION_INTENSITY_MM_MIN-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.DailyPrecipitation = (modbus->RxMsgBuf[(WS10_INP_REG_MET_DAILY_PRECIPITATION-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_DAILY_PRECIPITATION-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.GlobalRadiation = (modbus->RxMsgBuf[(WS10_INP_REG_MET_GLOBAL_RADIATION-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_GLOBAL_RADIATION-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.PositionOfTheSunAzimuth = (modbus->RxMsgBuf[(WS10_INP_REG_MET_POSITION_OF_THE_SUN_AZIMUTH-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_POSITION_OF_THE_SUN_AZIMUTH-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.PositionOfTheSunElevation = (modbus->RxMsgBuf[(WS10_INP_REG_MET_POSITION_OF_THE_SUN_ELEVATION-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_POSITION_OF_THE_SUN_ELEVATION-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.UVIndex = modbus->RxMsgBuf[(WS10_INP_REG_MET_UV_INDEX-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.Brightness = (modbus->RxMsgBuf[(WS10_INP_REG_MET_BRIGHTNESS-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_BRIGHTNESS-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10Current.Twilight = (modbus->RxMsgBuf[(WS10_INP_REG_MET_TWILIGHT-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+3]<<8) + modbus->RxMsgBuf[(WS10_INP_REG_MET_TWILIGHT-WS10_INP_REG_MET_AIR_TEMPERATURE)*2+4];
				WS10_LogBuffer();
				modbus->RxMsgEvent = 0;
				break;
			}
			case MODBUS_FUNC_READ_HOLDING_REGISTERS:
			{
				modbus->RxMsgEvent = 0;
				break;
			}
			default :
			{
				modbus->RxMsgEvent = 0;
				break;
			}
		}
	}
}


void WS10_AskData()
{
	ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgBuf[ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgCntr++] = 1;
	ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgBuf[ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgCntr++] = MODBUS_FUNC_READ_INPUT_REGISTERS;
	ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgBuf[ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgCntr++] = ((WS10_INP_REG_MET_AIR_TEMPERATURE & 0xff00)>>8);;
	ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgBuf[ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgCntr++] = (WS10_INP_REG_MET_AIR_TEMPERATURE & 0xff);
	ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgBuf[ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgCntr++] = (((WS10_INP_REG_MET_TWILIGHT - WS10_INP_REG_MET_AIR_TEMPERATURE + 1) & 0xff00)>>8);
	ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgBuf[ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgCntr++] = ((WS10_INP_REG_MET_TWILIGHT - WS10_INP_REG_MET_AIR_TEMPERATURE + 1) & 0xff);
	ModbusMaster[MODBUS_BUS_1].ComPort->TxMsgEvent = 1;
}

void finish_with_error(MYSQL *con)
{
  fprintf(stderr, "%s\n", mysql_error(con));
  mysql_close(con);
  //exit(1);
}

void WS10_DBCreate()
{
	MYSQL *con = mysql_init(NULL);

	if (con == NULL)
	{
		finish_with_error(con);
	}

	if (mysql_real_connect(con, "localhost", "root", "serra", NULL, 0, NULL, 0) == NULL)
	{
		finish_with_error(con);
	}

	if (mysql_query(con, "CREATE DATABASE IF NOT EXISTS ws10_log"))
	{
		finish_with_error(con);
	}

	mysql_close(con);
}

void WS10_LogTableCreate()
{
	MYSQL *con = mysql_init(NULL);

	if (con == NULL)
	{
		finish_with_error(con);
	}

	if (mysql_real_connect(con, "localhost", "root", "serra", "ws10_log", 0, NULL, 0) == NULL)
	{
		finish_with_error(con);
	}

	//if (mysql_query(con, "DROP TABLE IF EXISTS MeteoLog"))
	//{
	//	finish_with_error(con);
	//}

	if (mysql_query(con,
			"CREATE TABLE IF NOT EXISTS MeteoLog(\
			LogId INT PRIMARY KEY AUTO_INCREMENT, \
			Date DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, \
			AirTemperature SMALLINT, \
			DewpointTemperature SMALLINT, \
			RelativeHumidity SMALLINT UNSIGNED, \
			AbsoluteAirPressure SMALLINT UNSIGNED, \
			WindSpeed SMALLINT UNSIGNED, \
			WindDirectionCompass SMALLINT UNSIGNED, \
			PrecipitationType TINYINT UNSIGNED, \
			PrecipitationIntensity SMALLINT UNSIGNED, \
			DailyPrecipitation SMALLINT UNSIGNED, \
			GlobalRadiation SMALLINT UNSIGNED, \
			PositionOfTheSunAzimuth SMALLINT UNSIGNED, \
			PositionOfTheSunElevation SMALLINT UNSIGNED, \
			UVIndex TINYINT UNSIGNED, \
			Brightness SMALLINT UNSIGNED, \
			Twilight SMALLINT UNSIGNED \
			)"))
	{
		finish_with_error(con);
	}

	mysql_close(con);
}

/*
* function to reverse a string
*/
void my_reverse(char str[], int len)
{
    int start, end;
    char temp;
    for(start=0, end=len-1; start < end; start++, end--) {
        temp = *(str+start);
        *(str+start) = *(str+end);
        *(str+end) = temp;
    }
}

char* my_itoa(int num, char* str, int base)
{
    int i = 0;
    unsigned char isNegative = 0;

    /* A zero is same "0" string in all base */
    if (num == 0) {
        str[i] = '0';
        str[i + 1] = '\0';
        return str;
    }

    /* negative numbers are only handled if base is 10
       otherwise considered unsigned number */
    if (num < 0 && base == 10) {
        isNegative = 1;
        num = -num;
    }

    while (num != 0) {
        int rem = num % base;
        str[i++] = (rem > 9)? (rem-10) + 'A' : rem + '0';
        num = num/base;
    }

    /* Append negative sign for negative numbers */
    if (isNegative){
        str[i++] = '-';
    }

    str[i] = '\0';

    my_reverse(str, i);

    return str;
}


void WS10_LogMeasurement()
{
	MYSQL *con = mysql_init(NULL);

	if (con == NULL)
	{
		finish_with_error(con);
	}

	if (mysql_real_connect(con, "localhost", "root", "serra", "ws10_log", 0, NULL, 0) == NULL)
	{
		finish_with_error(con);
	}

	char *q = "INSERT INTO MeteoLog(AirTemperature,DewpointTemperature,RelativeHumidity,\
			AbsoluteAirPressure,WindSpeed,WindDirectionCompass,PrecipitationType,PrecipitationIntensity,\
			DailyPrecipitation,GlobalRadiation,PositionOfTheSunAzimuth,PositionOfTheSunElevation,\
			UVIndex,Brightness,Twilight) \
			VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)";

	size_t q_len = strlen(q);

	char at[50];
	char dt[50];
	char rh[50];
	char aap[50];
	char ws[50];
	char wdc[50];
	char pt[50];
	char pi[50];
	char dp[50];
	char gr[50];
	char posa[50];
	char pose[50];
	char ui[50];
	char br[50];
	char tw[50];
	char *air_temperature = my_itoa(WS10MinLog.AirTemperature, at, 10);
	char *dewpoint_temperature = my_itoa(WS10MinLog.DewpointTemperature, dt, 10);
	char *relative_humidity = my_itoa(WS10MinLog.RelativeHumidity, rh, 10);
	char *absolute_air_pressure = my_itoa(WS10MinLog.AbsoluteAirPressure, aap, 10);
	char *wind_speed = my_itoa(WS10MinLog.WindSpeed, ws, 10);
	char *wind_direction_compass = my_itoa(WS10MinLog.WindDirectionCompass, wdc, 10);
	char *precipitation_type = my_itoa(WS10MinLog.PrecititationType, pt, 10);
	char *precipitation_intensity = my_itoa(WS10MinLog.PrecititationIntensity, pi, 10);
	char *daily_precipitation = my_itoa(WS10MinLog.DailyPrecipitation, dp, 10);
	char *global_radiation = my_itoa(WS10MinLog.GlobalRadiation, gr, 10);
	char *position_of_the_sun_azimuth = my_itoa(WS10MinLog.PositionOfTheSunAzimuth, posa, 10);
	char *position_of_the_sun_elevation = my_itoa(WS10MinLog.PositionOfTheSunElevation, pose, 10);
	char *uv_index = my_itoa(WS10MinLog.UVIndex, ui, 10);
	char *brightness = my_itoa(WS10MinLog.Brightness, br, 10);
	char *twilight = my_itoa(WS10MinLog.Twilight, tw, 10);

	size_t air_temperature_len = strlen(air_temperature);
	size_t dewpoint_temperature_len = strlen(dewpoint_temperature);
	size_t relative_humidity_len = strlen(relative_humidity);
	size_t absolute_air_pressure_len = strlen(absolute_air_pressure);
	size_t wind_speed_len = strlen(wind_speed);
	size_t wind_direction_compass_len = strlen(wind_direction_compass);
	size_t precipitation_type_len = strlen(precipitation_type);
	size_t precipitation_intensity_len = strlen(precipitation_intensity);
	size_t daily_precipitation_len = strlen(daily_precipitation);
	size_t global_radiation_len = strlen(global_radiation);
	size_t position_of_the_sun_azimuth_len = strlen(position_of_the_sun_azimuth);
	size_t position_of_the_sun_elevation_len = strlen(position_of_the_sun_elevation);
	size_t uv_index_len = strlen(uv_index);
	size_t brightness_len = strlen(brightness);
	size_t twilight_len = strlen(twilight);

	unsigned int query_len = q_len
			   +air_temperature_len
			   +dewpoint_temperature_len
			   +relative_humidity_len
			   +absolute_air_pressure_len
			   +wind_speed_len
			   +wind_direction_compass_len
			   +precipitation_type_len
			   +precipitation_intensity_len
			   +daily_precipitation_len
			   +global_radiation_len
			   +position_of_the_sun_azimuth_len
			   +position_of_the_sun_elevation_len
			   +uv_index_len
			   +brightness_len
			   +twilight_len;

	char query[query_len];

	int len = snprintf(query,query_len
			,q
			,air_temperature
			,dewpoint_temperature
			,relative_humidity
			,absolute_air_pressure
			,wind_speed
			,wind_direction_compass
			,precipitation_type
			,precipitation_intensity
			,daily_precipitation
			,global_radiation
			,position_of_the_sun_azimuth
			,position_of_the_sun_elevation
			,uv_index
			,brightness
			,twilight
			);

	if (mysql_real_query(con,query,len))
	{
		finish_with_error(con);
	}

	mysql_close(con);
}

unsigned int WS10_FindMax(unsigned int num1, unsigned int num2)
{
	return (num1 > num2) ? (num1) : (num2);
}

void WS10_LogBuffer()
{
	WS10MinLogBuf[WS10Sens.LogCntr].AirTemperature = WS10Current.AirTemperature;
	WS10MinLogBuf[WS10Sens.LogCntr].DewpointTemperature = WS10Current.DewpointTemperature;
	WS10MinLogBuf[WS10Sens.LogCntr].RelativeHumidity = WS10Current.RelativeHumidity;
	WS10MinLogBuf[WS10Sens.LogCntr].AbsoluteAirPressure = WS10Current.AbsoluteAirPressure;
	WS10MinLogBuf[WS10Sens.LogCntr].WindSpeed = WS10Current.WindSpeed;
	WS10MinLogBuf[WS10Sens.LogCntr].WindDirectionCompass = WS10Current.WindDirectionCompass;
	WS10MinLogBuf[WS10Sens.LogCntr].PrecititationType = WS10Current.PrecititationType;
	WS10MinLogBuf[WS10Sens.LogCntr].PrecititationIntensity = WS10Current.PrecititationIntensity;
	WS10MinLogBuf[WS10Sens.LogCntr].DailyPrecipitation = WS10Current.DailyPrecipitation;
	WS10MinLogBuf[WS10Sens.LogCntr].GlobalRadiation = WS10Current.GlobalRadiation;
	WS10MinLogBuf[WS10Sens.LogCntr].PositionOfTheSunAzimuth = WS10Current.PositionOfTheSunAzimuth;
	WS10MinLogBuf[WS10Sens.LogCntr].PositionOfTheSunElevation = WS10Current.PositionOfTheSunElevation;
	WS10MinLogBuf[WS10Sens.LogCntr].UVIndex = WS10Current.UVIndex;
	WS10MinLogBuf[WS10Sens.LogCntr].Brightness = WS10Current.Brightness;
	WS10MinLogBuf[WS10Sens.LogCntr].Twilight = WS10Current.Twilight;
	WS10Sens.LogCntr++;

	if(WS10Sens.LogCntr >= WS10_LOG_BUF_LENGTH)
	{
		WS10Sens.LogCntr = 0;

		unsigned int i;

		int tmp_air_temperature = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_air_temperature += WS10MinLogBuf[i].AirTemperature;
		}
		tmp_air_temperature /= WS10_LOG_BUF_LENGTH;

		int tmp_dewpoint_temperature = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_dewpoint_temperature += WS10MinLogBuf[i].DewpointTemperature;
		}
		tmp_dewpoint_temperature /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_relative_humidity = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_relative_humidity += WS10MinLogBuf[i].RelativeHumidity;
		}
		tmp_relative_humidity /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_absolute_air_pressure = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_absolute_air_pressure += WS10MinLogBuf[i].AbsoluteAirPressure;
		}
		tmp_absolute_air_pressure /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_wind_speed = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_wind_speed += WS10MinLogBuf[i].WindSpeed;
		}
		tmp_wind_speed /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_wind_direction_compass = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_wind_direction_compass += WS10MinLogBuf[i].WindDirectionCompass;
		}
		tmp_wind_direction_compass /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_precipitation_no_cntr = 0;
		unsigned int tmp_precipitation_rain_cntr = 0;
		unsigned int tmp_precipitation_snow_cntr = 0;
		unsigned int tmp_precipitation_hail_cntr = 0;
		unsigned int tmp_precipitation_error_cntr = 0;
		unsigned int tmp_precipitation_type;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			switch(WS10MinLogBuf[i].PrecititationType)
			{
				case WS10_INP_REG_MET_PRECIPITATION_TYPE_NO_PRECIPITATION:
				{
					tmp_precipitation_no_cntr++;
					break;
				}
				case WS10_INP_REG_MET_PRECIPITATION_TYPE_LIQUD_RAIN:
				{
					tmp_precipitation_rain_cntr++;
					break;
				}
				case WS10_INP_REG_MET_PRECIPITATION_TYPE_SOLID_SNOW:
				{
					tmp_precipitation_snow_cntr++;
					break;
				}
				case WS10_INP_REG_MET_PRECIPITATION_TYPE_HAIL:
				{
					tmp_precipitation_hail_cntr++;
					break;
				}
				case WS10_INP_REG_MET_PRECIPITATION_TYPE_ERROR:
				{
					tmp_precipitation_error_cntr++;
					break;
				}
				default :
				{
					tmp_precipitation_error_cntr++;
					break;
				}
			}
		}

		unsigned int tmp_max_precipitation = WS10_FindMax(tmp_precipitation_no_cntr, WS10_FindMax(tmp_precipitation_rain_cntr,WS10_FindMax(tmp_precipitation_snow_cntr,WS10_FindMax(tmp_precipitation_hail_cntr,tmp_precipitation_error_cntr))));

		if(tmp_max_precipitation == tmp_precipitation_no_cntr)
		{
			tmp_precipitation_type = WS10_INP_REG_MET_PRECIPITATION_TYPE_NO_PRECIPITATION;
		}
		else if(tmp_max_precipitation == tmp_precipitation_rain_cntr)
		{
			tmp_precipitation_type = WS10_INP_REG_MET_PRECIPITATION_TYPE_LIQUD_RAIN;
		}
		else if(tmp_max_precipitation == tmp_precipitation_snow_cntr)
		{
			tmp_precipitation_type = WS10_INP_REG_MET_PRECIPITATION_TYPE_SOLID_SNOW;
		}
		else if(tmp_max_precipitation == tmp_precipitation_hail_cntr)
		{
			tmp_precipitation_type = WS10_INP_REG_MET_PRECIPITATION_TYPE_HAIL;
		}
		else //error
		{
			tmp_precipitation_type = WS10_INP_REG_MET_PRECIPITATION_TYPE_ERROR;
		}

		unsigned int tmp_precipitation_intensity = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_precipitation_intensity += WS10MinLogBuf[i].PrecititationIntensity;
		}
		tmp_precipitation_intensity /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_daily_precipitation = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_daily_precipitation += WS10MinLogBuf[i].DailyPrecipitation;
		}
		tmp_daily_precipitation /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_global_radiation = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_global_radiation += WS10MinLogBuf[i].GlobalRadiation;
		}
		tmp_global_radiation /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_position_of_the_sun_azimuth = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_position_of_the_sun_azimuth += WS10MinLogBuf[i].PositionOfTheSunAzimuth;
		}
		tmp_position_of_the_sun_azimuth /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_position_of_the_sun_elevation = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_position_of_the_sun_elevation += WS10MinLogBuf[i].PositionOfTheSunElevation;
		}
		tmp_position_of_the_sun_elevation /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_uv_index = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_uv_index += WS10MinLogBuf[i].UVIndex;
		}
		tmp_uv_index /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_brightness = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_brightness += WS10MinLogBuf[i].Brightness;
		}
		tmp_brightness /= WS10_LOG_BUF_LENGTH;

		unsigned int tmp_twilight = 0;
		for(i=0; i<WS10_LOG_BUF_LENGTH; i++)
		{
			tmp_twilight += WS10MinLogBuf[i].Twilight;
		}
		tmp_twilight /= WS10_LOG_BUF_LENGTH;

		WS10MinLog.AirTemperature = tmp_air_temperature;
		WS10MinLog.DewpointTemperature = tmp_dewpoint_temperature;
		WS10MinLog.RelativeHumidity = tmp_relative_humidity;
		WS10MinLog.AbsoluteAirPressure = tmp_absolute_air_pressure;
		WS10MinLog.WindSpeed = tmp_wind_speed;
		WS10MinLog.WindDirectionCompass = tmp_wind_direction_compass;
		WS10MinLog.PrecititationType = tmp_precipitation_type;
		WS10MinLog.PrecititationIntensity = tmp_precipitation_intensity;
		WS10MinLog.DailyPrecipitation = tmp_daily_precipitation;
		WS10MinLog.GlobalRadiation = tmp_global_radiation;
		WS10MinLog.PositionOfTheSunAzimuth = tmp_position_of_the_sun_azimuth;
		WS10MinLog.PositionOfTheSunElevation = tmp_position_of_the_sun_elevation;
		WS10MinLog.UVIndex = tmp_uv_index;
		WS10MinLog.Brightness = tmp_brightness;
		WS10MinLog.Twilight = tmp_twilight;

		WS10_LogMeasurement();
	}
}
