/*
 * main.c
 *
 *  Created on: Mar 14, 2020
 *      Author: root
 */

#include "main_includes.h"

int main(int argc, char*argv[])
{
	WS10_DBCreate();
	WS10_LogTableCreate();
	INIT_FNCT_GPIO();
	INIT_FNCT_SysTmr();
	INIT_FNCT_RealTimeClock();
	INIT_FNCT_SerialPort();
	INIT_FNCT_ModbusMaster();
	INIT_FNCT_WS10();

	while(1)
	{
		PROC_FNCT_SerialPort();
		PROC_FNCT_RealTimeClock();
		PROC_FNCT_ModbusMaster(&ModbusMaster[MODBUS_BUS_1]);
		PROC_FNCT_WS10();
	}

    return 0;
}

