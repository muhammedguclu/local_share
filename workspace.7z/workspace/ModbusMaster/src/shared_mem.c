/*
 * shared_mem.c
 *
 *  Created on: Mar 14, 2020
 *      Author: root
 */

#include "main_includes.h"

short* SharedMemPtr;

void SHARED_MEM_ReportAndExit(const char *msg)
{
	perror(msg);
	exit(-1);
}

void INIT_FNCT_SharedMem()
{
	int fd = shm_open(SHARED_MEM_BACKING_FILE, (O_RDWR | O_CREAT), SHARED_MEM_ACCESS_PERMS);

	if(fd < 0)
	{
		SHARED_MEM_ReportAndExit("Can't open shared mem segment...");
	}

	ftruncate(fd, SHARED_MEM_BYTE_SIZE);

	SharedMemPtr = mmap(
					NULL,
					SHARED_MEM_BYTE_SIZE,
					(PROT_READ | PROT_WRITE),
					MAP_SHARED,
					fd,
					0
					);

	if((short) -1 == SharedMemPtr)
	{
		SHARED_MEM_ReportAndExit("Can't get segment...");
	}

	fprintf(stderr,"shared mem address: %p [0..%d]\n", SharedMemPtr, (SHARED_MEM_BYTE_SIZE-1));
	fprintf(stderr, "backing file:       /dev/shm%s\n", SHARED_MEM_BACKING_FILE);

	//munmap(SharedMemPtr, SHARED_MEM_BYTE_SIZE);
	//close(fd);
	//shm_unlink(SHARED_MEM_BACKING_FILE);
}

void SHARED_MEM_WriteAllRegs()
{
	memcpy(SharedMemPtr,InputReg,INPUT_REGISTER_LENGTH);

	short hold_reg_vals[HOLDING_REGISTER_LENGTH];

	unsigned int i;
	for(i=0;i<HOLDING_REGISTER_LENGTH;i++)
	{
		hold_reg_vals[i] = HoldingReg[i].Data;
	}

	memcpy((SharedMemPtr+INPUT_REGISTER_LENGTH),hold_reg_vals,HOLDING_REGISTER_LENGTH);
}

