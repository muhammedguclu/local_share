/*
 * raspi_gateway.c
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#include "main_includes.h"

RASPI_GATEWAY_STR RaspiGateway;

void RASPI_GATEWAY_ChangeMode(unsigned char mode)
{
	HoldingReg[HOLD_REG_OPERATION_MODE].Data = mode;
	RaspiGateway.Mode = HoldingReg[HOLD_REG_OPERATION_MODE].Data;
}

void INIT_FNCT_RaspiGateway()
{
	ANALOG_MUX_EnablePort(MODBUS_BUS_1);
}

void PROC_FNCT_RaspiGateway()
{
	switch(RaspiGateway.Mode)
	{
		case HOLD_REG_OPERATION_MODE_FIRST_TEST:
		{
			break;
		}
		case HOLD_REG_OPERATION_MODE_OPERATION:
		{
			PROC_FNCT_Rs485GatewaySlave();
			break;
		}
		case HOLD_REG_OPERATION_MODE_REMOTE_PROGRAMMING:
		{
			break;
		}
		default:
		{
			break;
		}
	}
}
