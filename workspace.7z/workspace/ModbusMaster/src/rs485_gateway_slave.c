/*
 * rs485_gateway_slave.c
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#include "main_includes.h"

RS485_GATEWAY_SLAVE_STR Rs485GatewaySlave[RS485_GATEWAY_SLAVE_LENGTH];

void RS485_GATEWAY_SLAVE_ReadAllRs485GatewayInputRegisters(RS485_GATEWAY_SLAVE_STR *rs485_gateway_slave)
{
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = rs485_gateway_slave->SlaveAddrOnBus;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = MODBUS_FUNC_READ_INPUT_REGISTERS;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = 0;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = 0;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = ((RS485_GATEWAY_OWN_INPUT_REGISTER_LENGTH & 0xff00)>>8);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = (RS485_GATEWAY_OWN_INPUT_REGISTER_LENGTH & 0xff);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgEvent = 1;
}

void RS485_GATEWAY_SLAVE_ReadAllRs485GatewayHoldingRegisters(RS485_GATEWAY_SLAVE_STR *rs485_gateway_slave)
{
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = rs485_gateway_slave->SlaveAddrOnBus;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = MODBUS_FUNC_READ_HOLDING_REGISTERS;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = 0;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = 0;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = ((RS485_GATEWAY_OWN_HOLDING_REGISTER_LENGTH & 0xff00)>>8);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = (RS485_GATEWAY_OWN_HOLDING_REGISTER_LENGTH & 0xff);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgEvent = 1;
}

void RS485_GATEWAY_SLAVE_ReadSolarTrackerSlaveRegisters(RS485_GATEWAY_SLAVE_STR *rs485_gateway_slave, unsigned char slave_num)
{
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = rs485_gateway_slave->SlaveAddrOnBus;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = MODBUS_FUNC_READ_INPUT_REGISTERS;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = ((((RS485_GATEWAY_OWN_INPUT_REGISTER_LENGTH) + ((SOLAR_TRACKER_SLAVE_INP_REG_LENGTH + SOLAR_TRACKER_SLAVE_HOLD_REG_LENGTH)*slave_num)) & 0xff00)>>8);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = (((RS485_GATEWAY_OWN_INPUT_REGISTER_LENGTH) + ((SOLAR_TRACKER_SLAVE_INP_REG_LENGTH + SOLAR_TRACKER_SLAVE_HOLD_REG_LENGTH)*slave_num)) & 0xff);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = (((SOLAR_TRACKER_SLAVE_INP_REG_LENGTH + SOLAR_TRACKER_SLAVE_HOLD_REG_LENGTH) & 0xff00)>>8);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = ((SOLAR_TRACKER_SLAVE_INP_REG_LENGTH + SOLAR_TRACKER_SLAVE_HOLD_REG_LENGTH) & 0xff);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgEvent = 1;
}

void RS485_GATEWAY_SLAVE_WriteSingleOrMultiSlaveSingleRegister(RS485_GATEWAY_SLAVE_STR *rs485_gateway_slave, short slave_hold_reg, short slave_hold_reg_val)
{
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = rs485_gateway_slave->SlaveAddrOnBus;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = MODBUS_FUNC_WRITE_MULTIPLE_REGISTERS;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = ((slave_hold_reg & 0xff00)>>8);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = (slave_hold_reg & 0xff);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = 0;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = 1;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = 2;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = ((slave_hold_reg_val & 0xff00)>>8);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = (slave_hold_reg_val & 0xff);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgEvent = 1;
}

void RS485_GATEWAY_SLAVE_WriteSingleOrMultiSlaveMultipleRegister(RS485_GATEWAY_SLAVE_STR *rs485_gateway_slave)
{
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = rs485_gateway_slave->SlaveAddrOnBus;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = MODBUS_FUNC_WRITE_MULTIPLE_REGISTERS;
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = ((HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_MULTIPLE_REGISTER_WRITE_START].Data & 0xff00)>>8);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = (HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_MULTIPLE_REGISTER_WRITE_START].Data & 0xff);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = ((HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_MULTIPLE_REGISTER_WRITE_NUM_OF_SHORTS].Data & 0xff00)>>8);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = (HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_MULTIPLE_REGISTER_WRITE_NUM_OF_SHORTS].Data & 0xff);
	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = (HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_MULTIPLE_REGISTER_WRITE_NUM_OF_SHORTS].Data*2);

	unsigned char i;
	for(i=0; i<HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_MULTIPLE_REGISTER_WRITE_NUM_OF_SHORTS].Data;i++)
	{
		ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = ((HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_MULTIPLE_REGISTER_WRITE_SHORT_0+i].Data & 0xff00)>>8);
		ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgBuf[ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgCntr++] = (HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_MULTIPLE_REGISTER_WRITE_SHORT_0+i].Data & 0xff);
	}

	ModbusMaster[rs485_gateway_slave->ModbusMasterBusAddr].ComPort->TxMsgEvent = 1;
}


void RS485_GATEWAY_SLAVE_EnableTimerTask()
{
	if(RaspiGateway.Rs485SlaveEnableCounter == 0)
	{
		if(HoldingReg[HOLD_REG_WRITE_SINGLE_OR_MULTI_SLAVE_SINGLE_REGISTER].Event == 1)
		{
			RaspiGateway.Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_WRITE_HOLD_REG;
			HoldingReg[HOLD_REG_WRITE_SINGLE_OR_MULTI_SLAVE_SINGLE_REGISTER].Event = 0;
		}
		else if(HoldingReg[HOLD_REG_WRITE_SINGLE_OR_MULTI_SLAVE_MULTIPLE_REGISTER].Event == 1)
		{
			RaspiGateway.Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_WRITE_MULTIPLE_HOLD_REG;
			HoldingReg[HOLD_REG_WRITE_SINGLE_OR_MULTI_SLAVE_MULTIPLE_REGISTER].Event = 0;
		}
		else
		{
			if(RaspiGateway.Rs485SlaveAskWhat == RS485_GATEWAY_SLAVE_ASK_OWN_INPUT_REGISTERS)
			{
				RaspiGateway.Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_ASK_OWN_HOLDING_REGISTERS;
			}
			else if(RaspiGateway.Rs485SlaveAskWhat == RS485_GATEWAY_SLAVE_ASK_OWN_HOLDING_REGISTERS)
			{
				RaspiGateway.Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_ASK_SOLAR_TRACKER_SLAVE_REGISTERS;
			}
			else if(RaspiGateway.Rs485SlaveAskWhat == RS485_GATEWAY_SLAVE_ASK_SOLAR_TRACKER_SLAVE_REGISTERS)
			{

			}
			else if(RaspiGateway.Rs485SlaveAskWhat == RS485_GATEWAY_SLAVE_WRITE_DATA_TO_SHARED_MEM)
			{
				RaspiGateway.Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_ASK_OWN_INPUT_REGISTERS;
			}
			else
			{
				RaspiGateway.Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_ASK_OWN_INPUT_REGISTERS;
			}
		}
	}

	if(RaspiGateway.Rs485SlaveAskWhat != RS485_GATEWAY_SLAVE_ASK_SOLAR_TRACKER_SLAVE_REGISTERS)
	{
		Rs485GatewaySlave[RaspiGateway.Rs485SlaveEnableCounter].PortEnableEvent = 1;
		RaspiGateway.Rs485SlaveEnableCounter++;

		if(RaspiGateway.Rs485SlaveEnableCounter >= HoldingReg[HOLD_REG_MAX_NUMBER_OF_SLAVES].Data)
		{
			RaspiGateway.Rs485SlaveEnableCounter = 0;
		}
	}
	else
	{
		if(RaspiGateway.Rs485SlaveAskSubSlave < Rs485GatewaySlave[RaspiGateway.Rs485SlaveEnableCounter].MaxNumberOfPorts)
		{
			RaspiGateway.Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_ASK_SOLAR_TRACKER_SLAVE_REGISTERS;
			Rs485GatewaySlave[RaspiGateway.Rs485SlaveEnableCounter].PortEnableEvent = 1;
		}
		else
		{
			RaspiGateway.Rs485SlaveAskSubSlave = 0;
			RaspiGateway.Rs485SlaveEnableCounter++;
			if(RaspiGateway.Rs485SlaveEnableCounter >= HoldingReg[HOLD_REG_MAX_NUMBER_OF_SLAVES].Data)
			{
				RaspiGateway.Rs485SlaveEnableCounter = 0;
				RaspiGateway.Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_WRITE_DATA_TO_SHARED_MEM;
			}
			else
			{
				RaspiGateway.Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_ASK_SOLAR_TRACKER_SLAVE_REGISTERS;
			}
			Rs485GatewaySlave[RaspiGateway.Rs485SlaveEnableCounter].PortEnableEvent = 1;
		}
	}

}

void RS485_GATEWAY_SLAVE_ReadTimerTask()
{
	Rs485GatewaySlave[RaspiGateway.Rs485SlaveReadBuf].AskEvent = 1;
}

void INIT_FNCT_Rs485GatewaySlave()
{
	RaspiGateway.Rs485SlaveEnableCounter = 0;
	RaspiGateway.Rs485SlaveReadBuf = 0;
	RaspiGateway.Rs485SlaveAskWhat = RS485_GATEWAY_SLAVE_WRITE_DATA_TO_SHARED_MEM;

	unsigned char i;

	if(RaspiGateway.Mode != HOLD_REG_OPERATION_MODE_FIRST_TEST)
	{
		for(i=0; i<HoldingReg[HOLD_REG_MAX_NUMBER_OF_SLAVES].Data; i++)
		{
			Rs485GatewaySlave[i].SlaveAddrOnBus = INPUT_REG_GetRowValueFromFile(RASPI_GATEWAY_CONFIG_FILE, (CONFIG_FILE_SLAVE_ADDR_0_ADDR+i));
		}
	}
	else
	{
		for(i=0; i<RS485_GATEWAY_SLAVE_LENGTH; i++)
		{
			Rs485GatewaySlave[i].SlaveAddrOnBus = 0xff;
		}
	}

	if(RaspiGateway.Mode != HOLD_REG_OPERATION_MODE_FIRST_TEST)
	{
		for(i=0; i<HoldingReg[HOLD_REG_MAX_NUMBER_OF_SLAVES].Data; i++)
		{
			Rs485GatewaySlave[i].ModbusMasterBusAddr = INPUT_REG_GetRowValueFromFile(RASPI_GATEWAY_CONFIG_FILE, (CONFIG_FILE_SLAVE_PORT_0_ADDR+i));
		}
	}
	else
	{
		for(i=0; i<RS485_GATEWAY_SLAVE_LENGTH; i++)
		{
			Rs485GatewaySlave[i].ModbusMasterBusAddr = MODBUS_BUS_1;
		}
	}

	if(RaspiGateway.Mode != HOLD_REG_OPERATION_MODE_FIRST_TEST)
	{
		for(i=0; i<HoldingReg[HOLD_REG_MAX_NUMBER_OF_SLAVES].Data; i++)
		{
			Rs485GatewaySlave[i].MaxNumberOfPorts = INPUT_REG_GetRowValueFromFile(RASPI_GATEWAY_CONFIG_FILE, (CONFIG_FILE_SLAVE_MAX_NUM_OF_PORTS_0_ADDR+i));
		}
	}
	else
	{
		for(i=0; i<RS485_GATEWAY_SLAVE_LENGTH; i++)
		{
			Rs485GatewaySlave[i].MaxNumberOfPorts = 16;
		}
	}

	if(RaspiGateway.Mode != HOLD_REG_OPERATION_MODE_FIRST_TEST)
	{
		TmrSetTmrType(RASPI_GATEWAY_TIMER, TMR_TYPE_CONTINUOUS);
		TmrCfgCriticFnct(RASPI_GATEWAY_TIMER, RS485_GATEWAY_SLAVE_EnableTimerTask, (void *) 0);
		TmrSetTmrInitTick(RASPI_GATEWAY_TIMER, RASPI_GATEWAY_TIMER_TICK);
		TmrResetTick(RASPI_GATEWAY_TIMER);
		TmrStart(RASPI_GATEWAY_TIMER);
	}

}

void PROC_FNCT_Rs485GatewaySlave()
{
	unsigned char i;

	for(i=0; i<HoldingReg[HOLD_REG_MAX_NUMBER_OF_SLAVES].Data; i++)
	{
		if(Rs485GatewaySlave[i].PortEnableEvent == 1)
		{
			ANALOG_MUX_EnablePort(Rs485GatewaySlave[i].ModbusMasterBusAddr);
			RaspiGateway.Rs485SlaveReadBuf = i;

			if(RaspiGateway.Mode != HOLD_REG_OPERATION_MODE_FIRST_TEST)
			{
				TmrSetTmrType(ANALOG_MUX_TIMER, TMR_TYPE_SINGLE);
				TmrCfgCriticFnct(ANALOG_MUX_TIMER, RS485_GATEWAY_SLAVE_ReadTimerTask, (void *) 0);
				TmrSetTmrInitTick(ANALOG_MUX_TIMER, ANALOG_MUX_TIMER_TICK);
				TmrResetTick(ANALOG_MUX_TIMER);
				TmrStart(ANALOG_MUX_TIMER);
			}

			Rs485GatewaySlave[i].PortEnableEvent = 0;
		}
	}

	for(i=0; i<HoldingReg[HOLD_REG_MAX_NUMBER_OF_SLAVES].Data; i++)
	{
		if(Rs485GatewaySlave[i].AskEvent == 1)
		{
			switch(RaspiGateway.Rs485SlaveAskWhat)
			{
				case RS485_GATEWAY_SLAVE_ASK_OWN_INPUT_REGISTERS:
				{
					RS485_GATEWAY_SLAVE_ReadAllRs485GatewayInputRegisters(&Rs485GatewaySlave[i]);
					break;
				}
				case RS485_GATEWAY_SLAVE_ASK_OWN_HOLDING_REGISTERS:
				{
					RS485_GATEWAY_SLAVE_ReadAllRs485GatewayHoldingRegisters(&Rs485GatewaySlave[i]);
					break;
				}
				case RS485_GATEWAY_SLAVE_ASK_SOLAR_TRACKER_SLAVE_REGISTERS:
				{
					RS485_GATEWAY_SLAVE_ReadSolarTrackerSlaveRegisters(&Rs485GatewaySlave[i], RaspiGateway.Rs485SlaveAskSubSlave);
					RaspiGateway.Rs485SlaveAskSubSlave++;
					break;
				}
				case RS485_GATEWAY_SLAVE_WRITE_HOLD_REG:
				{
					if(HoldingReg[HOLD_REG_WRITE_SINGLE_OR_MULTI_SLAVE_SINGLE_REGISTER].Data == HOLD_REG_WRITE_SINGLE_OR_MULTI_SLAVE_SINGLE_REGISTER_ALL_SLAVES)
					{
						RS485_GATEWAY_SLAVE_WriteSingleOrMultiSlaveSingleRegister(&Rs485GatewaySlave[i], HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_SINGLE_REGISTER_WRITE_SLAVE_REG_NUM].Data, HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_SINGLE_REGISTER_SLV_0+i].Data);
					}
					else if(HoldingReg[HOLD_REG_WRITE_SINGLE_OR_MULTI_SLAVE_SINGLE_REGISTER].Data == i)
					{
						RS485_GATEWAY_SLAVE_WriteSingleOrMultiSlaveSingleRegister(&Rs485GatewaySlave[i], HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_SINGLE_REGISTER_WRITE_SLAVE_REG_NUM].Data, HoldingReg[HOLD_REG_WRITE_S_O_M_SLAVE_SINGLE_REGISTER_SLV_0+i].Data);
					}
					break;
				}
				case RS485_GATEWAY_SLAVE_WRITE_MULTIPLE_HOLD_REG:
				{
					if(HoldingReg[HOLD_REG_WRITE_SINGLE_OR_MULTI_SLAVE_MULTIPLE_REGISTER].Data == HOLD_REG_WRITE_SINGLE_OR_MULTI_SLAVE_SINGLE_REGISTER_ALL_SLAVES)
					{
						RS485_GATEWAY_SLAVE_WriteSingleOrMultiSlaveMultipleRegister(&Rs485GatewaySlave[i]);
					}
					else if(HoldingReg[HOLD_REG_WRITE_SINGLE_OR_MULTI_SLAVE_MULTIPLE_REGISTER].Data == i)
					{
						RS485_GATEWAY_SLAVE_WriteSingleOrMultiSlaveMultipleRegister(&Rs485GatewaySlave[i]);
					}
					break;
				}
				case RS485_GATEWAY_SLAVE_WRITE_DATA_TO_SHARED_MEM:
				{
					SHARED_MEM_WriteAllRegs();
					break;
				}
				default :
				{
					break;
				}
			}
			MODBUS_MASTER_ChkTxMsg(Rs485GatewaySlave[i].ModbusMasterBusAddr);
			//TmrSetTmrType(SERIAL_PORT_READ_TIMER, TMR_TYPE_SINGLE);
			//TmrCfgCriticFnct(SERIAL_PORT_READ_TIMER, PROC_FNCT_SerialPort, (void *) 0);
			//TmrSetTmrInitTick(SERIAL_PORT_READ_TIMER, SERIAL_PORT_READ_TIMER_TICK);
			//TmrResetTick(SERIAL_PORT_READ_TIMER);
			//TmrStart(SERIAL_PORT_READ_TIMER);
			Rs485GatewaySlave[i].AskEvent = 0;
		}
	}

	RS485_GATEWAY_SLAVE_HandleMsg(&ModbusMaster[Rs485GatewaySlave[RaspiGateway.Rs485SlaveReadBuf].ModbusMasterBusAddr]);
}

void RS485_GATEWAY_SLAVE_HandleMsg(MODBUS_MASTER_STR *modbus)
{
	if(modbus->RxMsgEvent == 1)
	{
		switch(modbus->RxMsgBuf[MODBUS_INDEX_FUNCTION])
		{
			case MODBUS_FUNC_READ_INPUT_REGISTERS:
			{
				unsigned char i;
				if(RaspiGateway.Rs485SlaveAskSubSlave != 0)
				{
					for(i=0; i<(SOLAR_TRACKER_SLAVE_INP_REG_LENGTH + SOLAR_TRACKER_SLAVE_HOLD_REG_LENGTH); i++)
					{
						InputReg[(RASPI_NUMBER_OF_OWN_INPUT_REGISTERS + RaspiGateway.Rs485SlaveReadBuf * (RS485_GATEWAY_MAIN_MEMORY_INP_REG_LENGTH + RS485_GATEWAY_MAIN_MEMORY_HOLD_REG_LENGTH + RS485_GATEWAY_MAX_NUMBER_OF_SLAVES * (SOLAR_TRACKER_SLAVE_INP_REG_LENGTH + SOLAR_TRACKER_SLAVE_HOLD_REG_LENGTH))) + (RS485_GATEWAY_MAIN_MEMORY_INP_REG_LENGTH + RS485_GATEWAY_MAIN_MEMORY_HOLD_REG_LENGTH) + (RaspiGateway.Rs485SlaveAskSubSlave-1) * (SOLAR_TRACKER_SLAVE_INP_REG_LENGTH + SOLAR_TRACKER_SLAVE_HOLD_REG_LENGTH) + i].Data = (modbus->RxMsgBuf[i*2+3]<<8) + modbus->RxMsgBuf[i*2+4];
					}
				}
				else
				{
					for(i=0; i<RS485_GATEWAY_OWN_INPUT_REGISTER_LENGTH; i++)
					{
						InputReg[(RASPI_NUMBER_OF_OWN_INPUT_REGISTERS + RaspiGateway.Rs485SlaveReadBuf * (RS485_GATEWAY_MAIN_MEMORY_INP_REG_LENGTH + RS485_GATEWAY_MAIN_MEMORY_HOLD_REG_LENGTH + RS485_GATEWAY_MAX_NUMBER_OF_SLAVES * (SOLAR_TRACKER_SLAVE_INP_REG_LENGTH + SOLAR_TRACKER_SLAVE_HOLD_REG_LENGTH))) + i].Data = (modbus->RxMsgBuf[i*2+3]<<8) + modbus->RxMsgBuf[i*2+4];
					}
				}
				modbus->RxMsgEvent = 0;
				break;
			}
			case MODBUS_FUNC_READ_HOLDING_REGISTERS:
			{
				unsigned char i;
				for(i=RS485_GATEWAY_HOLD_REG_OPERATION_MODE; i<RS485_GATEWAY_OWN_HOLDING_REGISTER_LENGTH; i++)
				{
					InputReg[(RASPI_NUMBER_OF_OWN_INPUT_REGISTERS + RaspiGateway.Rs485SlaveReadBuf * (RS485_GATEWAY_MAIN_MEMORY_INP_REG_LENGTH + RS485_GATEWAY_MAIN_MEMORY_HOLD_REG_LENGTH + RS485_GATEWAY_MAX_NUMBER_OF_SLAVES * (SOLAR_TRACKER_SLAVE_INP_REG_LENGTH + SOLAR_TRACKER_SLAVE_HOLD_REG_LENGTH))) + RS485_GATEWAY_MAIN_MEMORY_INP_REG_LENGTH + i].Data = (modbus->RxMsgBuf[i*2+3]<<8) + modbus->RxMsgBuf[i*2+4];
				}
				modbus->RxMsgEvent = 0;
				break;
			}
			default :
			{
				break;
			}
		}
	}
}

