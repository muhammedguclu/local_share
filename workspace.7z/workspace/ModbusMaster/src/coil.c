/*
 * coil.c
 *
 *  Created on: Jan 24, 2020
 *      Author: root
 */

#include "main_includes.h"

COIL_STR Coil[COIL_LENGTH];

void INIT_FNCT_Coil()
{
	Coil[COIL_0].Address = 26;
	Coil[COIL_1].Address = 11;
	Coil[COIL_2].Address = 27;
	Coil[COIL_3].Address = 2;
}

void COIL_SetSingleData(COIL_STR *coil, unsigned char value)
{
	gpioWrite(coil->Address, value);
}

unsigned char COIL_GetSingleData(COIL_STR *coil)
{
	return gpioRead(coil->Address);
}
