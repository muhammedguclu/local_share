/*
 * serial_util.c
 *
 *  Created on: May 23, 2019
 *      Author: pi
 */

#include "main_includes.h"

COM_PORT SerialPort1;

void INIT_FNCT_SerialPort()
{
	if((SerialPort1.Address = serialOpen("/dev/ttyS0", 9600)) < 0)	/* open serial port */
	{
		fprintf(stderr, "Unable to open serial device: %s\n", strerror (errno)) ;
	}

	if (wiringPiSetup() == -1)					/* initializes wiringPi setup */
	{
		fprintf(stdout, "Unable to start wiringPi: %s\n", strerror (errno)) ;
	}
}

int CheckComPortRx(COM_PORT *com_port)
{
	return serialDataAvail(com_port->Address);
}

void ReadMessage(COM_PORT *com_port, unsigned int message_length)
{
	unsigned int i;
	for(i=0; i<message_length; i++)
	{
		unsigned char data = serialGetchar(com_port->Address);
		com_port->RxDataBuf[com_port->RxCntr++] = data; /* receive character serially*/
		if(com_port->RxCntr >= SERIAL_COM_PORT_BUF_LEN)
		{
			com_port->RxCntr = 0;
		}
		//printf("%02x", data);
		//fflush(stdout);
	}
}

void SendMessage(COM_PORT *com_port, unsigned int message_length, char *ch)
{
	gpioWrite(18, 1);
	usleep(10000);
	unsigned int i = 0;
	for(i=0; i<message_length; i++)
	{
		serialPutchar(com_port->Address, *(ch++));
		usleep(1100);
	}
	//usleep(11000);
	gpioWrite(18, 0);
}

void PROC_FNCT_SerialPort()
{
	unsigned int serial_port_buf = CheckComPortRx(&SerialPort1);
	if(serial_port_buf > 0)
	{
		ReadMessage(&SerialPort1, serial_port_buf);
	}
}

